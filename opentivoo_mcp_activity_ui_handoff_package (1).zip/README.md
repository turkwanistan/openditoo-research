# OpenTivoo MCP Activity UI Handoff Package

This package contains the current approved UI baseline and the preferred activity-behavior variant for an OpenTivoo MCP activity page.

## Goal

Implement a 16×16 RGB222 page that monitors 3 MCPs:

1. **OptiPlex Lab** → mushroom + letter **L**
2. **OptiPlex MCP** → bunny + letter **O**
3. **WSL MCP** → skull + letter **W**

The page should show:

- each MCP's identity;
- a status color based on how recent the last transmission was;
- a packet/activity animation when traffic occurs.

## Current preferred behavior

The **baseline layout** is the approved composition.
The **blue override variant** is the preferred activity behavior:

- during an activity animation, the active column's **top activity crown**, **letter**, and **icon status accent** pulse blue together;
- after the animation completes, that column returns to its normal status color.

## Quick file guide

### assets/baseline_layout
Use these for the approved composition and spacing baseline.

### assets/blue_override_variant
Use these for the approved activity behavior experiment that the user selected as preferred.

### assets/source_primitives
Exact 5×5 source sprites for mushroom, rabbit, and skull.

### docs
Implementation guidance, layout spec, state mapping, and hook contract suggestions.

## Recommended implementation target

Build the app around:

- **baseline layout** for geometry / spacing
- **blue override variant** for interaction behavior

